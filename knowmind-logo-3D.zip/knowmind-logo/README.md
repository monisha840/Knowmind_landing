# KnowMind tumbling mark

The rotating infinity logo, self-contained. No dependencies, no build step, no
framework required.

## Files

- `tumbling-mark.html` — open in a browser. Working demo, nothing to install.
- `tumbling-mark.css` — the styles. Both versions need this.
- `TumblingMark.jsx` — React component. Imports the CSS beside it.

## React

    import { TumblingMark } from "./TumblingMark";

    <TumblingMark height={30} />                  // header size
    <TumblingMark height={90} seconds={20} />     // large, slower
    <TumblingMark height={30} label="Acme Inc" /> // named for screen readers

It is `aria-hidden` by default. Pass `label` only when the mark is the *only*
thing naming its link — beside a wordmark, leave it hidden, because announcing
the brand twice in one link is worse than not announcing it at all.

## Plain HTML

Copy the `svg.km-defs` block into the document ONCE, then the `.km-mark` markup
wherever you want a mark. Do not repeat the defs per mark: duplicate element ids
are invalid, and removing the first instance strips the gradient from all the
others.

## Why it is built this way

**A stack, not one SVG.** A flat path rotated on Y vanishes to a hairline every
half turn, which at logo size reads as a glitch. Thirteen copies 0.5px apart
inside a `preserve-3d` parent extrude it into a slab with something to show
edge-on.

**Layer count and spacing are a pair.** The tube renders about 1.3px wide at
header size, so a gap wider than that shows daylight between the slices and the
mark reads as a coil of separate rings rather than one object. If you scale the
mark up a long way, raise DEPTH in proportion.

**Only the two faces carry the glow.** The glow is an feGaussianBlur, and
rasterising one per layer per frame is most of the cost. Dropping it from the
eleven interior slices cut paint and raster work by about a third — worth having
on a header that renders on every page.

**Reduced motion stops it.** The CSS honours `prefers-reduced-motion` and holds
the mark flat.

## Using your own shape

Replace the `d` attribute. It is a lemniscate of Bernoulli sampled to a polyline
on a 240x120 viewBox. Anything drawn on that viewBox works; keep the three
stroke widths in the same 9 / 6 / 1.6 ratio and it will read the same way.
